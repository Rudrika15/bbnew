<div class="list-group list-group-flush h-100">
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('reseller.dashboard') }}">
        <i class="bi bi-speedometer"></i> Dashboard
    </a>
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('reseller.user.index') }}">
        <i class="bi bi-people-fill"></i> User List
    </a>
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('reseller.passbook') }}">
        <i class="bi bi-journal-arrow-up"></i> Passbook
    </a>


</div>
