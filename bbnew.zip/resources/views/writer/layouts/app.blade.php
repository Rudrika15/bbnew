<div class="list-group list-group-flush">
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('writer.dashboard') }}">
        <i class="bi bi-speedometer"></i> Dashboard
    </a>
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('writer.slugs.index') }}">
        <i class="bi bi-vector-pen"></i> My Slogan
    </a>
</div>
