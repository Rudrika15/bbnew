<div class="list-group list-group-flush">
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('designer.dashboard') }}">
        <i class="bi bi-speedometer"></i> Dashboard
    </a>
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('designer.index') }}">
        <i class="bi bi-pencil-square"></i> Slogans
    </a>
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('designer.show') }}">
        <i class="bi bi-images"></i> My Designs
    </a>
</div>
