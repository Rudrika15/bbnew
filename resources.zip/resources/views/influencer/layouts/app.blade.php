<div class="list-group list-group-flush">
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('influencer.dashboard') }}">
        <i class="bi bi-speedometer"></i> Dashboard
    </a>
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('influencer.brands') }}">
        <i class="bi bi-person-hearts"></i> Brands
    </a>
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('influencer.campaignApplyList') }}">
        <i class="bi bi-person-hearts"></i> My Applied Campaign
    </a>
    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('influencer.package.index') }}">
        <i class="bi bi-person-hearts"></i> Influencer Packages
    </a>

</div>
